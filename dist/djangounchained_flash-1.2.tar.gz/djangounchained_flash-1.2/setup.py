from setuptools import setup

setup(
    name='djangounchained_flash',
    version='1.2',
    description='Flash messaging for setup',
    author='Ashwin Mahesh',
    author_email='mahesh2@purdue.edu',
    license='None',
    packages=['djangounchained_flash'],
    zip_safe=False
)